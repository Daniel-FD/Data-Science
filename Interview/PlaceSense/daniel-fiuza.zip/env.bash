conda create --name placesense-env python==3.8 -y
conda activate placesense-env
